#ifndef CANDEFINES_H
#define CANDEFINES_H
#include <QVector>
/*Byte order*/
typedef enum {
    E_CANByteOrder_Intel_Sequential = 0,
    E_CANByteOrder_Intel_Standard,
}E_CANIntelByteOrder;

typedef enum {
    E_CANByteOrder_Motorola_ForwardLSB = 0,
    E_CANByteOrder_Motorola_ForwardMSB,
    E_CANByteOrder_Motorola_Sequential,
    E_CANByteOrder_Motorola_Backward
}E_CANMotByteOrder;

typedef enum {
        E_CANByteOrder_Intel = 0,
       E_CANByteOrder_Motorola = 1,
}E_CANByteOrder;
/*End Byte order*/

/*Signed*/
typedef enum {
    E_CANSignalSign_Signed=0,
    E_CANSignalSign_UnSigned,
    E_CANSignalSign_Float,
    E_CANSignalSign_Double,
}E_CANSignalSign;
/*End signed*/

/*ID type*/
typedef enum {
    E_CANMsgIDType_Standard=0,
    E_CANMsgIDType_Extended
}E_CANMsgIDType;
/*End ID type*/

/*union value in different types*/
typedef union{
    long long lValue;
    unsigned long long uValue;
    float fValue;
    double dValue;
}U_CANValue;
/*End union value in different types*/

typedef struct  {
    QString m_Name; // signal names
    QString m_Comment; // signal comments
    unsigned char m_Length; //length in bit
    E_CANByteOrder m_ByteOrder;
    E_CANSignalSign m_ValueType;
    U_CANValue m_InitValue;
    U_CANValue m_Factor;
    U_CANValue m_Offset;
    U_CANValue m_Min;
    U_CANValue m_Max;
    U_CANValue m_Unit;

}CANSignal;

typedef struct{
    unsigned char m_StartBit;
    CANSignal * m_Signal;
}CANSignalInMessage;

typedef struct{
    QString m_Name; // signal names
    QString m_Comment; // signal comments
    unsigned char m_Length; //length in byte
    unsigned int m_ID;
    E_CANMsgIDType m_IdType;
    QVector<CANSignalInMessage> m_Signals;
}CANMessage;

//typedef struct{
//    CANSignal * SignalCan;
//    CANMessage * MessCan;
//    CANSignalInMessage * SigMsgCan;
//}CANframe;

#endif // CANDEFINES_H
